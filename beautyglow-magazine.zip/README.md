# BeautyGlow Magazine (Next.js + Tailwind)

Ready-to-deploy sample "beauty magazine" site.

## How to run locally
1. Extract the zip.
2. In the project folder run:
   ```bash
   npm install
   npm run dev
   ```
3. Open http://localhost:3000

## Deploy to Vercel
1. Create a Vercel account (if you don't have one).
2. Import a Git repository or choose "Upload" and upload the project zip.
3. Vercel will detect Next.js and deploy automatically.
