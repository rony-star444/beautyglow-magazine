export default function Tips(){
  const tips = [
    { id:1, title:'Skincare Before Makeup', body:'Cleanse, moisturize, and use SPF.' },
    { id:2, title:'Choosing Foundation', body:'Match on jawline in natural light.' },
    { id:3, title:'Makeup Longevity', body:'Use setting spray and translucent powder.' }
  ]
  return (
    <section className="py-16 px-4">
      <div className="container mx-auto max-w-3xl">
        <h2 className="text-3xl font-bold text-center mb-8">Beauty Tips</h2>
        <div className="space-y-4">
          {tips.map(t=>(
            <div key={t.id} className="bg-white p-4 rounded shadow">
              <h3 className="font-semibold">{t.title}</h3>
              <p className="text-sm text-muted mt-2">{t.body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
