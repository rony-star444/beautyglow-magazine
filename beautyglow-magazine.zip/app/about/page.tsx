export default function About(){
  return (
    <section className="py-16 px-4">
      <div className="container mx-auto max-w-3xl text-center">
        <h2 className="text-3xl font-bold mb-6">About BeautyGlow</h2>
        <p className="text-muted">BeautyGlow is a digital magazine dedicated to makeup tips, product reviews and easy-to-follow tutorials made for everyone. Our mission is to help you feel confident and radiant.</p>
      </div>
    </section>
  )
}
