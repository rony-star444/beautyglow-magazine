import ProductCard from '../../components/ProductCard'
const products = [
  { id: 1, title: 'Luminous Foundation', price: 42, img: 'https://placehold.co/400x300?text=Foundation' },
  { id: 2, title: 'Pro Eyeshadow Palette', price: 58, img: 'https://placehold.co/400x300?text=Eyeshadow' },
  { id: 3, title: 'Satin Lipstick', price: 28, img: 'https://placehold.co/400x300?text=Lipstick' }
]
export default function Products() {
  return (
    <section className="py-16 px-4">
      <div className="container mx-auto">
        <h2 className="text-3xl font-bold text-center mb-8">Products</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {products.map(p=> <ProductCard key={p.id} product={p} />)}
        </div>
      </div>
    </section>
  )
}
