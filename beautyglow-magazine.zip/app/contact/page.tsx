'use client'
import { useState } from 'react'
export default function Contact(){
  const [name,setName] = useState('')
  const [email,setEmail] = useState('')
  const [message,setMessage] = useState('')
  const handleSubmit = (e:any)=>{
    e.preventDefault()
    alert('Thanks! We received your message.')
    setName(''); setEmail(''); setMessage('')
  }
  return (
    <section className="py-16 px-4">
      <div className="container mx-auto max-w-lg">
        <h2 className="text-3xl font-bold mb-6 text-center">Contact Us</h2>
        <form onSubmit={handleSubmit} className="space-y-4 bg-white p-6 rounded shadow">
          <input required placeholder="Name" value={name} onChange={e=>setName(e.target.value)} className="w-full p-3 border rounded"/>
          <input required type="email" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} className="w-full p-3 border rounded"/>
          <textarea required placeholder="Message" value={message} onChange={e=>setMessage(e.target.value)} className="w-full p-3 border rounded h-32"/>
          <button className="px-5 py-2 bg-primary text-white rounded">Send Message</button>
        </form>
      </div>
    </section>
  )
}
