export default function Tutorials(){
  const tutorials = [
    { id:1, title:'Everyday Natural Look', time:'15 min', img:'https://placehold.co/600x400?text=Natural' },
    { id:2, title:'Dramatic Smokey Eye', time:'25 min', img:'https://placehold.co/600x400?text=Smokey' },
    { id:3, title:'Bridal Beauty', time:'30 min', img:'https://placehold.co/600x400?text=Bridal' }
  ]
  return (
    <section className="py-16 px-4 bg-muted/10">
      <div className="container mx-auto">
        <h2 className="text-3xl font-bold text-center mb-8">Tutorials</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {tutorials.map(t=>(
            <div key={t.id} className="bg-white rounded shadow overflow-hidden">
              <img src={t.img} alt={t.title} className="w-full h-44 object-cover"/>
              <div className="p-4">
                <h3 className="font-semibold">{t.title}</h3>
                <p className="text-sm text-muted mt-2">{t.time} • {t.title.includes('Bridal')? 'All Levels':'Beginner'}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
